// ColoredPoint.js (c) 2012 matsuda
// Vertex shader program
var VSHADER_SOURCE = `
  attribute vec4 a_Position;
  uniform float u_Size; 
  void main() {
    gl_Position = a_Position;
    // gl_PointSize = 30.0;
    gl_PointSize = u_Size;
  }`;

// Fragment shader program
var FSHADER_SOURCE = `
  precision mediump float;
  uniform vec4 u_FragColor;
  void main() {
    gl_FragColor = u_FragColor;
  }`;

// Global Variables
let canvas;
let gl;
let a_Position;
let u_FragColor;
let u_Size;

function setupWebGL() {
  // Retrieve <canvas> element
  canvas = document.getElementById('webgl');

  // Get the rendering context for WebGL
  // gl = getWebGLContext(canvas);
  gl = canvas.getContext("webgl", { preserveDrawingBuffer: true});
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }
  
}

function connectVariablesToGLSL() {
  // Initialize shaders
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
    console.log('Failed to intialize shaders.');
    return;
  }

  // // Get the storage location of a_Position
  a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
    console.log('Failed to get the storage location of a_Position');
    return;
  }

  // Get the storage location of u_FragColor
  u_FragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
  if (!u_FragColor) {
    console.log('Failed to get the storage location of u_FragColor');
    return;
  }

  // Get the storage location of u_Size
  u_Size = gl.getUniformLocation(gl.program, 'u_Size');
  if (!u_Size) {
    console.log('Failed to get the storage location of u_Size');
    return;
  }
  
}

// Constants
const POINT = 0;
const TRIANGLE = 1;
const CIRCLE = 2;

// Globals related to UI elements;
let g_selectedColor = [1.0,1.0,1.0,1.0];
let g_selectedSize = 5;
let g_selectedType = POINT;
let g_selectedSegments = 10;

function addActionsForHtmlUI() {
  // Button Events (Shape Type)
  document.getElementById('green').onclick = function() { g_selectedColor = [0.0,1.0,0.0,1.0]; };
  document.getElementById('red').onclick   = function() { g_selectedColor = [1.0,0.0,0.0,1.0]; };
  document.getElementById('clearButton').onclick = function() { g_shapesList=[]; renderAllShapes(); };

  document.getElementById('pointButton').onclick = function() { g_selectedType=POINT; };
  document.getElementById('triButton').onclick = function() { g_selectedType=TRIANGLE; };
  document.getElementById('cirButton').onclick = function() { g_selectedType=CIRCLE; };

  document.getElementById('drawPicture').onclick = function() { drawMyPicture(); };

  document.getElementById('undoButton').onclick = function() {
    g_shapesList.pop();
    renderAllShapes();
  };

  // Slider Events
  document.getElementById('redSlide').addEventListener('mouseup',   function() { g_selectedColor[0] = this.value/100; });
  document.getElementById('greenSlide').addEventListener('mouseup', function() { g_selectedColor[1] = this.value/100; });
  document.getElementById('blueSlide').addEventListener('mouseup',  function() { g_selectedColor[2] = this.value/100; });

  // Size Slider Event
  document.getElementById('sizeSlide').addEventListener('mouseup',  function() { g_selectedSize = this.value; });

  // Circle Segment Event
  document.getElementById('segSlide').addEventListener('mouseup', function() { g_selectedSegments = this.value; });
}

function main() {

  // Set up canvas and gl variables
  setupWebGL();

  // Set up GLSL shader programs and connect GLSL variables
  connectVariablesToGLSL();

  // Set up actions for the HTML UI elements
  addActionsForHtmlUI();
  
  // Register function (event handler) to be called on a mouse press
  canvas.onmousedown = click;
  // canvas.onmousemove = click;
  canvas.onmousemove = function(ev) { if(ev.buttons == 1) { click(ev) } };
  
  // Specify the color for clearing <canvas>
  gl.clearColor(0.0, 0.0, 0.0, 1.0);

  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);
}

var g_shapesList = [];

// var g_points = [];  // The array for the position of a mouse press
// var g_colors = [];  // The array to store the color of a point
// var g_sizes = [];

function click(ev) {
  // Extract the event click and return it in WebGL coordinates
  let [x,y] = convertCoordinatesEventToGL(ev);

  // Create and store the new point
  let point;
  if (g_selectedType == POINT) {
    point = new Point();
  } else if (g_selectedType == TRIANGLE) {
    point = new Triangle();
  } else if (g_selectedType == CIRCLE)   { 
    point = new Circle();
  }
  
  point.position = [x, y];
  point.color = g_selectedColor.slice();
  point.size = g_selectedSize;
  point.segments = g_selectedSegments;
  g_shapesList.push(point);
  

  // Draw every shape that is supposed to be in the canvas
  renderAllShapes();
  
}

function convertCoordinatesEventToGL(ev) {
  var x = ev.clientX; // x coordinate of a mouse pointer
  var y = ev.clientY; // y coordinate of a mouse pointer
  var rect = ev.target.getBoundingClientRect();

  x = ((x - rect.left) - canvas.width/2)/(canvas.width/2);
  y = (canvas.height/2 - (y - rect.top))/(canvas.height/2);

  return([x,y]); 
}

function renderAllShapes() {
  // Check the time at the start of this function
  var startTime = performance.now();
  
  // Clear <canvas>
  gl.clear(gl.COLOR_BUFFER_BIT);

//  var len = g_points.length;
  var len = g_shapesList.length; 
  
  for(var i = 0; i < len; i++) {
    g_shapesList[i].render();
  }

  // Check the time at the end of the function, and show on web page
  var duration = performance.now() - startTime;
  sendTextToHTML("numdot: " + len + " ms: " + Math.floor(duration) + " fps: " + Math.floor(10000/duration)/10, "numdot");
  
}

// Set the text of a HTML element
function sendTextToHTML(text, htmlID) {
  var htmlElm = document.getElementById(htmlID);
  if (!htmlElm) {
    console.log("Failed to get " + htmlID + " from HTML");
    return;
  }
  htmlElm.innerHTML = text;
}

function drawMyPicture() {
  gl.clear(gl.COLOR_BUFFER_BIT);
  
  // --- LIGHT GRAY: body parts ---
  gl.uniform4f(u_FragColor, 0.75, 0.75, 0.75, 1.0);
  
  // HEAD
  drawTriangle([-0.6,  0.20,   0.0,  0.20,  -0.6,  0.72]);
  drawTriangle([ 0.0,  0.20,   0.0,  0.72,  -0.6,  0.72]);
  
  // LEFT EAR
  drawTriangle([-0.55, 0.72,  -0.38, 0.72,  -0.47, 0.95]);
  
  // RIGHT EAR
  drawTriangle([-0.22, 0.72,  -0.05, 0.72,  -0.13, 0.95]);
  
  // UPPER BODY
  drawTriangle([-0.6, -0.10,   0.35, -0.10,  -0.6,  0.20]);
  drawTriangle([ 0.35, -0.10,  0.35,  0.20,  -0.6,  0.20]);
  
  // LEFT FRONT LEG
  drawTriangle([-0.55, -0.50,  -0.28, -0.50,  -0.55, -0.10]);
  drawTriangle([-0.28, -0.50,  -0.28, -0.10,  -0.55, -0.10]);
  
  // RIGHT FRONT LEG
  drawTriangle([-0.15, -0.50,   0.12, -0.50,  -0.15, -0.10]);
  drawTriangle([ 0.12, -0.50,   0.12, -0.10,  -0.15, -0.10]);
  
  // BACK
  drawTriangle([ 0.35, -0.10,   0.60, -0.10,   0.35,  0.20]);
  drawTriangle([ 0.60, -0.10,   0.60, -0.40,   0.35, -0.10]);
  
  // TAIL
  drawTriangle([ 0.35,  0.10,   0.60,  0.30,   0.60,  0.10]);
  drawTriangle([ 0.60,  0.10,   0.80,  0.00,   0.60, -0.10]);
  drawTriangle([ 0.60,  0.30,   0.80,  0.10,   0.80,  0.30]);
  
  // BLACK
  gl.uniform4f(u_FragColor, 0.1, 0.1, 0.1, 1.0);
  
  // LEFT EYE
  drawTriangle([-0.52, 0.58,  -0.33, 0.58,  -0.42, 0.40]);
  
  // RIGHT EYE
  drawTriangle([-0.27, 0.58,  -0.08, 0.58,  -0.17, 0.40]);
  
  // MOUTH
  drawTriangle([-0.42, 0.38,  -0.18, 0.38,  -0.30, 0.25]);
  
  // LEFT PAW
  drawTriangle([-0.55, -0.50,  -0.28, -0.50,  -0.42, -0.65]);
  
  // RIGHT PAW
  drawTriangle([-0.15, -0.50,   0.12, -0.50,  -0.02, -0.65]);
}
